

export const index = 2;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/2.aVoaSdop.js","_app/immutable/chunks/scheduler.S4wXxuDW.js","_app/immutable/chunks/index.XLnFJMlX.js","_app/immutable/chunks/singletons.EjCKJ5I1.js"];
export const stylesheets = [];
export const fonts = [];
