

export const index = 1;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/fallbacks/error.svelte.js')).default;
export const imports = ["_app/immutable/nodes/1.XZOxT8du.js","_app/immutable/chunks/scheduler.S4wXxuDW.js","_app/immutable/chunks/index.XLnFJMlX.js","_app/immutable/chunks/stores.w_UHE4Rf.js","_app/immutable/chunks/singletons.EjCKJ5I1.js"];
export const stylesheets = [];
export const fonts = [];
