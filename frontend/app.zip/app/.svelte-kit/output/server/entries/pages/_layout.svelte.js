import { c as create_ssr_component, b as subscribe, v as validate_component } from "../../chunks/ssr.js";
import { p as page } from "../../chunks/stores.js";
const Navbar = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $page, $$unsubscribe_page;
  $$unsubscribe_page = subscribe(page, (value) => $page = value);
  $$unsubscribe_page();
  return `<div class="flex flex-row justify-center items-center p-5 gap-8 bg-slate-300 shadow-md h-24"><i class="fa-solid fa-bus text-2xl"></i> <a class="${[
    "border-white text-xl hover:text-white",
    $page.url.href?.includes("/employees") ? "border-b-4" : ""
  ].join(" ").trim()}" href="/employees" data-svelte-h="svelte-m91d88">Employees</a> <a class="${[
    "border-white text-xl hover:text-white",
    $page.url.href?.includes("/map") ? "border-b-4" : ""
  ].join(" ").trim()}" href="/map" data-svelte-h="svelte-pvs8x9">Map</a> <a class="${[
    "border-white text-xl hover:text-white",
    $page.url.href?.includes("/routes") ? "border-b-4" : ""
  ].join(" ").trim()}" href="/routes" data-svelte-h="svelte-kvvt1r">Routes</a></div>`;
});
const Layout = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  return `${validate_component(Navbar, "Navbar").$$render($$result, {}, {}, {})} ${slots.default ? slots.default({}) : ``}`;
});
export {
  Layout as default
};
