import { c as create_ssr_component, d as each, e as escape } from "../../../chunks/ssr.js";
function getRoutes() {
  return [
    {
      id: "01",
      name: "FAT",
      stops: [
        { number: 1, name: "Dworzec Główny" },
        { number: 2, name: "Plac Grundwaldzki" }
      ]
    },
    {
      id: "01",
      name: "FAT",
      stops: [
        { number: 1, name: "Dworzec Główny" },
        { number: 2, name: "Plac Grundwaldzki" }
      ]
    }
  ];
}
const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let routes = getRoutes();
  return `<div class="p-3 flex flex-col justify-center items-center gap-8">${each(routes, (route) => {
    return `<div class="flex flex-col"><div class="flex flex-row gap-4 text-3xl bg-slate-300 p-2"><h1>${escape(route.id)}</h1> <h3>${escape(route.name)}</h3></div> ${each(route.stops, (stop) => {
      return `<div class="flex flex-row gap-2"><p><strong>${escape(stop.number)}</strong></p> <p>${escape(stop.name)}</p> </div>`;
    })} </div>`;
  })}</div>`;
});
export {
  Page as default
};
