import { c as create_ssr_component, d as each, f as add_attribute, e as escape } from "../../../chunks/ssr.js";
const css = {
  code: "table.svelte-giidjo,th.svelte-giidjo,td.svelte-giidjo{border:1px solid}td.svelte-giidjo{padding:4px}",
  map: null
};
function getEmployeesData() {
  return [
    {
      id: "01",
      firstName: "Jan",
      lastName: "Kowalski",
      balance: 100
    },
    {
      id: "02",
      firstName: "Mateusz",
      lastName: "Kowalski",
      balance: 20
    }
  ];
}
const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let employees = getEmployeesData();
  let editEmployeeId;
  let formData = {
    id: "",
    firstName: "",
    lastName: "",
    balance: ""
  };
  $$result.css.add(css);
  return `<div class="p-5 flex flex-col items-center gap-5"><h1 class="text-xl" data-svelte-h="svelte-1cy9px9"><strong>Employees List</strong></h1> <table class="w-4/6 text-lg border-collapse border-solid border-black border-2 svelte-giidjo"><tr data-svelte-h="svelte-d0v4q8"><th class="svelte-giidjo">Id</th> <th class="svelte-giidjo">First Name</th> <th class="svelte-giidjo">Last Name</th> <th class=" svelte-giidjo">Balance</th></tr> ${each(employees, (employee) => {
    return `<tr class=""><td class="svelte-giidjo">${escape(employee.id)}</td> <td class="svelte-giidjo">${escape(employee.firstName)}</td> <td class="svelte-giidjo">${escape(employee.lastName)}</td> <td class="svelte-giidjo"><div class="flex flex-row justify-between px-2">${editEmployeeId !== employee.id ? `<h2 class="w-10 border-2 border-white">${escape(employee.balance)}</h2> <button data-svelte-h="svelte-1xwm2tb"><i class="fa-solid fa-pen-to-square"></i> </button>` : `<input class="w-10 border-2 rounded-md" type="number"${add_attribute("id", employee.id, 0)}${add_attribute("value", employee.balance, 0)}> <button data-svelte-h="svelte-1ejpw27"><i class="fa-solid fa-upload"></i> </button>`} </div></td> </tr>`;
  })}</table> <div class="flex flex-col justify-center items-center gap-5"><h1 class="text-xl" data-svelte-h="svelte-1wq6fr5"><strong>Add New Employee</strong></h1> <form action="" id="add_form"><table class="svelte-giidjo"><tr><td class="svelte-giidjo"><input class="" type="text" placeholder="Id" id="id" name="id"${add_attribute("value", formData.id, 0)}> <label for="id" class="hidden" data-svelte-h="svelte-1tybtld">Id</label></td> <td class="svelte-giidjo"><input type="text" placeholder="First Name" id="name" name="firstName"${add_attribute("value", formData.firstName, 0)}> <label for="name" class="hidden" data-svelte-h="svelte-upaiqf">First Name</label></td> <td class="svelte-giidjo"><input type="text" placeholder="Last Name" id="lastname" name="lastName"${add_attribute("value", formData.lastName, 0)}> <label for="lastname" class="hidden" data-svelte-h="svelte-6a8ghb">Last Name</label></td> <td class="svelte-giidjo"><input type="value" placeholder="Balance" id="form_balance" name="balance"${add_attribute("value", formData.balance, 0)}> <label for="form_balance" class="hidden" data-svelte-h="svelte-cq5wo">Balance</label></td></tr></table></form> <button data-svelte-h="svelte-89vjzp"><i class="fa-solid fa-circle-plus text-4xl"></i></button></div> </div>`;
});
export {
  Page as default
};
